// Basic Chatbot logic
const chatbox = document.getElementById('chatbox');
const userInput = document.getElementById('userInput');
const sendBtn = document.getElementById('sendBtn');

// Function to handle sending messages
function sendMessage() {
    const message = userInput.value.trim();
    if (message) {
        displayMessage('User: ' + message);
        userInput.value = '';

        // Simple response logic
        setTimeout(() => {
            const response = getBotResponse(message);
            displayMessage('Bot: ' + response);
        }, 1000);
    }
}

// Function to display messages in chatbox
function displayMessage(message) {
    const msgDiv = document.createElement('div');
    msgDiv.textContent = message;
    chatbox.appendChild(msgDiv);
    chatbox.scrollTop = chatbox.scrollHeight; // Scroll to bottom
}

// Function to generate bot responses
function getBotResponse(input) {
    // Simple response logic
    const responses = {
        'hi': 'Hello! just tell me what services you are looking for',
        'how are you?': 'I am a bot, I do not have feelings!',
        'bye': 'Goodbye!',
        'what is this app?':'this is a online service providing application which provide human efforrt needed services through online application',
        'default': 'I am not sure how to respond to that.'
    };
    return responses[input.toLowerCase()] || responses['default'];
}

// Event listener for the send button
sendBtn.addEventListener('click', sendMessage);

// Allow pressing "Enter" to send a message
userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        sendMessage();
    }
});
